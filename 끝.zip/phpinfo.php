<?php 

phpinfo();


?>