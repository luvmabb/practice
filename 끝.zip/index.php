<!DOCTYPE html>
<html>
    <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MAKELOGINPAGE</title>

      <!-- 스타일시트 -->
    <!-- <link rel="stylesheet" type="text/css" href="css/join_black.css"> -->
    <link rel="stylesheet" type="text/css" href="css/join.css">
    </head>
    <body>
   <!-- form 시작 -->
   <h2>MAKE LOGIN PAGE</h2>
   <a href="login_view.php" class="button">Go to login!</a>
    </body>
</html>