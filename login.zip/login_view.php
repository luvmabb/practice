<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>로그인</title>

    <!-- 컨트롤+/ = 주석처리 -->


     <!-- 스타일시트 -->
    <!-- <link rel="stylesheet" type="text/css" href="css/join_black.css"> -->
    <link rel="stylesheet" type="text/css" href="css/join.css">
</head>
<body>
    <!-- form 시작 -->
<form action="login_server.php" method="post">
<h2>로그인</h2>

<?php if(isset($_GET['error']))
{?>
<p class="error"><?php echo $_GET['error']; ?></p>
<?php } ?>

<?php if(isset($_GET['success']))
{?>
<p class="success"><?php echo $_GET['success']; ?></p>
<?php } ?>


<label>ID</label>
<input type="text" placeholder="ID 입력" name="user_id">

<label>PW</label>
<input type="password" placeholder="PW 입력" name="user_pw1" >


<button type="submit" name="login_btn">로그인</button>
<a href="register.php" class="save">아직 회원 아니신가요? (회원가입 페이지)</a>

</form>
</body>
</html>

